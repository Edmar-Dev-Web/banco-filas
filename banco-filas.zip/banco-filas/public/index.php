<?php include("../config/db.php"); ?>
<?php include("../includes/header.php"); ?>

<div class="container mt-5">
    <h2 class="text-center">Gerador de Senhas - Banco</h2>
    <p class="text-center">Selecione o serviço para gerar sua senha:</p>

    <form action="senha.php" method="POST" class="text-center">
        <select name="servico_id" class="form-select w-50 mx-auto mb-3" required>
            <option value="">-- Escolha o Serviço --</option>
            <?php
            $sql = $pdo->query("SELECT * FROM servicos");
            while($row = $sql->fetch(PDO::FETCH_ASSOC)) {
                echo "<option value='{$row['id']}'>{$row['nome']}</option>";
            }
            ?>
        </select>
        <button type="submit" class="btn btn-primary">Gerar Senha</button>
    </form>
</div>

<?php include("../includes/footer.php"); ?>
