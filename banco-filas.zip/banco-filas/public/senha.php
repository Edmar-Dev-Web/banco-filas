<?php
include("../config/db.php");

if (isset($_POST['servico_id'])) {
    $servico_id = $_POST['servico_id'];

    // Pega última senha do serviço
    $sql = $pdo->prepare("SELECT MAX(numero) as ultimo FROM senhas WHERE servico_id = ?");
    $sql->execute([$servico_id]);
    $row = $sql->fetch(PDO::FETCH_ASSOC);
    $novoNumero = $row['ultimo'] ? $row['ultimo'] + 1 : 1;

    // Insere nova senha
    $stmt = $pdo->prepare("INSERT INTO senhas (numero, servico_id) VALUES (?, ?)");
    $stmt->execute([$novoNumero, $servico_id]);

    // Pega o nome do serviço
    $sql = $pdo->prepare("SELECT nome FROM servicos WHERE id = ?");
    $sql->execute([$servico_id]);
    $servico = $sql->fetch(PDO::FETCH_ASSOC);
}
?>
<?php include("../includes/header.php"); ?>

<div class="container text-center mt-5">
    <h3>Sua Senha</h3>
    <div class="card p-4">
        <h1 class="display-3"> <?= $novoNumero ?> </h1>
        <p><strong>Serviço:</strong> <?= $servico['nome'] ?> </p>
    </div>
    <a href="index.php" class="btn btn-secondary mt-3">Voltar</a>
</div>

<?php include("../includes/footer.php"); ?>
