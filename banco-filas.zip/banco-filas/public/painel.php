<?php include("../config/db.php"); ?>
<?php include("../includes/header.php"); ?>

<div class="container mt-5">
    <h2 class="text-center">Painel de Chamadas</h2>
    <table class="table table-striped mt-4">
        <thead>
            <tr>
                <th>Senha</th>
                <th>Serviço</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sql = $pdo->query("SELECT s.numero, v.nome, s.status 
                                FROM senhas s 
                                JOIN servicos v ON s.servico_id = v.id 
                                ORDER BY s.data_geracao DESC 
                                LIMIT 10");
            while($row = $sql->fetch(PDO::FETCH_ASSOC)) {
                echo "<tr>
                        <td>{$row['numero']}</td>
                        <td>{$row['nome']}</td>
                        <td>{$row['status']}</td>
                      </tr>";
            }
            ?>
        </tbody>
    </table>
</div>

<?php include("../includes/footer.php"); ?>
